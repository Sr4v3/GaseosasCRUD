﻿namespace empresaGaseosas.UI
{
    partial class Products
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BtnSalir = new Button();
            IntProductId = new TextBox();
            label4 = new Label();
            TxtProductValue = new TextBox();
            LblUsuario = new Label();
            BtnIngresar = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            CBProductType = new ComboBox();
            CBProductState = new ComboBox();
            LblTitulo = new Label();
            TxtProductDescrip = new TextBox();
            BtnUpdate = new Button();
            BtnDelete = new Button();
            BtnConsultar = new Button();
            BtnCreateUser = new Button();
            SuspendLayout();
            // 
            // BtnSalir
            // 
            BtnSalir.BackColor = Color.Navy;
            BtnSalir.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnSalir.ForeColor = Color.White;
            BtnSalir.Location = new Point(743, 60);
            BtnSalir.Name = "BtnSalir";
            BtnSalir.Size = new Size(103, 36);
            BtnSalir.TabIndex = 12;
            BtnSalir.Text = "Salir";
            BtnSalir.UseVisualStyleBackColor = false;
            BtnSalir.Click += BtnSalir_Click;
            // 
            // IntProductId
            // 
            IntProductId.Font = new Font("Candara Light", 10F);
            IntProductId.Location = new Point(302, 89);
            IntProductId.Margin = new Padding(4, 5, 4, 5);
            IntProductId.Name = "IntProductId";
            IntProductId.Size = new Size(265, 24);
            IntProductId.TabIndex = 26;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Navy;
            label4.Location = new Point(40, 92);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(93, 19);
            label4.TabIndex = 30;
            label4.Text = "Id Producto:";
            // 
            // TxtProductValue
            // 
            TxtProductValue.Font = new Font("Candara Light", 10F);
            TxtProductValue.Location = new Point(302, 159);
            TxtProductValue.Margin = new Padding(4, 5, 4, 5);
            TxtProductValue.Name = "TxtProductValue";
            TxtProductValue.Size = new Size(265, 24);
            TxtProductValue.TabIndex = 27;
            // 
            // LblUsuario
            // 
            LblUsuario.AutoSize = true;
            LblUsuario.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            LblUsuario.ForeColor = Color.Navy;
            LblUsuario.Location = new Point(40, 161);
            LblUsuario.Margin = new Padding(4, 0, 4, 0);
            LblUsuario.Name = "LblUsuario";
            LblUsuario.Size = new Size(116, 19);
            LblUsuario.TabIndex = 29;
            LblUsuario.Text = "Valor producto:";
            // 
            // BtnIngresar
            // 
            BtnIngresar.BackColor = Color.Navy;
            BtnIngresar.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnIngresar.ForeColor = Color.White;
            BtnIngresar.Location = new Point(683, 380);
            BtnIngresar.Margin = new Padding(4, 5, 4, 5);
            BtnIngresar.Name = "BtnIngresar";
            BtnIngresar.Size = new Size(162, 58);
            BtnIngresar.TabIndex = 28;
            BtnIngresar.Text = "Insertar";
            BtnIngresar.UseVisualStyleBackColor = false;
            BtnIngresar.Click += BtnIngresar_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Navy;
            label1.Location = new Point(40, 285);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(169, 19);
            label1.TabIndex = 32;
            label1.Text = "Presentación producto:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Navy;
            label2.Location = new Point(40, 225);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(158, 19);
            label2.TabIndex = 33;
            label2.Text = "Descripción producto:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Navy;
            label3.Location = new Point(40, 344);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(147, 19);
            label3.TabIndex = 34;
            label3.Text = "Estado de producto:";
            // 
            // CBProductType
            // 
            CBProductType.Font = new Font("Candara Light", 10F);
            CBProductType.FormattingEnabled = true;
            CBProductType.Items.AddRange(new object[] { "--Seleccionar--", "   350mL", "   3L" });
            CBProductType.Location = new Point(302, 285);
            CBProductType.Name = "CBProductType";
            CBProductType.Size = new Size(265, 23);
            CBProductType.TabIndex = 35;
            // 
            // CBProductState
            // 
            CBProductState.Font = new Font("Candara Light", 10F);
            CBProductState.FormattingEnabled = true;
            CBProductState.Items.AddRange(new object[] { "--Seleccionar--", "   Activo", "   Inactivo" });
            CBProductState.Location = new Point(302, 341);
            CBProductState.Name = "CBProductState";
            CBProductState.Size = new Size(265, 23);
            CBProductState.TabIndex = 36;
            // 
            // LblTitulo
            // 
            LblTitulo.AutoSize = true;
            LblTitulo.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            LblTitulo.ForeColor = Color.Navy;
            LblTitulo.Location = new Point(335, 30);
            LblTitulo.Margin = new Padding(4, 0, 4, 0);
            LblTitulo.Name = "LblTitulo";
            LblTitulo.Size = new Size(205, 19);
            LblTitulo.TabIndex = 37;
            LblTitulo.Text = "Administración de productos\r\n";
            // 
            // TxtProductDescrip
            // 
            TxtProductDescrip.Font = new Font("Candara Light", 10F);
            TxtProductDescrip.Location = new Point(302, 225);
            TxtProductDescrip.Margin = new Padding(4, 5, 4, 5);
            TxtProductDescrip.Name = "TxtProductDescrip";
            TxtProductDescrip.Size = new Size(265, 24);
            TxtProductDescrip.TabIndex = 38;
            // 
            // BtnUpdate
            // 
            BtnUpdate.BackColor = Color.Navy;
            BtnUpdate.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnUpdate.ForeColor = Color.White;
            BtnUpdate.Location = new Point(683, 312);
            BtnUpdate.Margin = new Padding(4, 5, 4, 5);
            BtnUpdate.Name = "BtnUpdate";
            BtnUpdate.Size = new Size(162, 58);
            BtnUpdate.TabIndex = 39;
            BtnUpdate.Text = "Actualizar";
            BtnUpdate.UseVisualStyleBackColor = false;
            BtnUpdate.Click += BtnUpdate_Click;
            // 
            // BtnDelete
            // 
            BtnDelete.BackColor = Color.Navy;
            BtnDelete.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnDelete.ForeColor = Color.White;
            BtnDelete.Location = new Point(684, 244);
            BtnDelete.Margin = new Padding(4, 5, 4, 5);
            BtnDelete.Name = "BtnDelete";
            BtnDelete.Size = new Size(162, 58);
            BtnDelete.TabIndex = 40;
            BtnDelete.Text = "Inactivar";
            BtnDelete.UseVisualStyleBackColor = false;
            BtnDelete.Click += BtnDelete_Click;
            // 
            // BtnConsultar
            // 
            BtnConsultar.BackColor = Color.Navy;
            BtnConsultar.Font = new Font("Candara", 9F);
            BtnConsultar.ForeColor = Color.White;
            BtnConsultar.Location = new Point(575, 85);
            BtnConsultar.Margin = new Padding(4, 5, 4, 5);
            BtnConsultar.Name = "BtnConsultar";
            BtnConsultar.Size = new Size(117, 36);
            BtnConsultar.TabIndex = 41;
            BtnConsultar.Text = "Consultar";
            BtnConsultar.UseVisualStyleBackColor = false;
            BtnConsultar.Click += BtnConsultar_Click;
            // 
            // BtnCreateUser
            // 
            BtnCreateUser.BackColor = Color.Navy;
            BtnCreateUser.Font = new Font("Candara", 9F);
            BtnCreateUser.ForeColor = Color.White;
            BtnCreateUser.Location = new Point(703, 198);
            BtnCreateUser.Margin = new Padding(4, 5, 4, 5);
            BtnCreateUser.Name = "BtnCreateUser";
            BtnCreateUser.Size = new Size(117, 36);
            BtnCreateUser.TabIndex = 42;
            BtnCreateUser.Text = "Nuevo Usuario";
            BtnCreateUser.UseVisualStyleBackColor = false;
            BtnCreateUser.Click += BtnCreateUser_Click;
            // 
            // Products
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(884, 411);
            Controls.Add(BtnCreateUser);
            Controls.Add(BtnConsultar);
            Controls.Add(BtnDelete);
            Controls.Add(BtnUpdate);
            Controls.Add(TxtProductDescrip);
            Controls.Add(LblTitulo);
            Controls.Add(CBProductState);
            Controls.Add(CBProductType);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(IntProductId);
            Controls.Add(label4);
            Controls.Add(TxtProductValue);
            Controls.Add(LblUsuario);
            Controls.Add(BtnIngresar);
            Controls.Add(BtnSalir);
            Margin = new Padding(2);
            MinimizeBox = false;
            Name = "Products";
            SizeGripStyle = SizeGripStyle.Hide;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Productos";
            ResumeLayout(false);
            PerformLayout();
        }

        private Button BtnSalir;
        private TextBox IntProductId;
        private Label label4;
        private TextBox TxtProductValue;
        private Label LblUsuario;
        private Button BtnIngresar;
        private Label label1;
        private Label label2;
        private Label label3;
        private ComboBox CBProductType;
        private ComboBox CBProductState;
        private Label LblTitulo;
        private TextBox TxtProductDescrip;
        private Button BtnUpdate;
        private Button BtnDelete;
        private Button BtnConsultar;
        private Button BtnCreateUser;
        #endregion
    }
}