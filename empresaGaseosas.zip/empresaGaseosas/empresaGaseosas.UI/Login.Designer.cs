﻿namespace empresaGaseosas.UI
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            LblTitulo = new Label();
            TxtPassword = new TextBox();
            TxtUsuario = new TextBox();
            LblPassword = new Label();
            LblUsuario = new Label();
            BtnIngresar = new Button();
            BtnSalir = new Button();
            SuspendLayout();
            // 
            // LblTitulo
            // 
            LblTitulo.AutoSize = true;
            LblTitulo.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            LblTitulo.ForeColor = Color.Navy;
            LblTitulo.Location = new Point(110, 27);
            LblTitulo.Name = "LblTitulo";
            LblTitulo.Size = new Size(155, 38);
            LblTitulo.TabIndex = 15;
            LblTitulo.Text = "Empresa de Gaseosas\r\nLogin";
            LblTitulo.TextAlign = ContentAlignment.TopCenter;
            // 
            // TxtPassword
            // 
            TxtPassword.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            TxtPassword.Location = new Point(152, 131);
            TxtPassword.Name = "TxtPassword";
            TxtPassword.PasswordChar = '&';
            TxtPassword.Size = new Size(170, 27);
            TxtPassword.TabIndex = 2;
            TxtPassword.UseSystemPasswordChar = true;
            TxtPassword.KeyPress += TxtPassword_KeyPress;
            // 
            // TxtUsuario
            // 
            TxtUsuario.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            TxtUsuario.Location = new Point(152, 93);
            TxtUsuario.Name = "TxtUsuario";
            TxtUsuario.Size = new Size(170, 27);
            TxtUsuario.TabIndex = 1;
            // 
            // LblPassword
            // 
            LblPassword.AutoSize = true;
            LblPassword.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            LblPassword.ForeColor = Color.Navy;
            LblPassword.Location = new Point(50, 137);
            LblPassword.Name = "LblPassword";
            LblPassword.Size = new Size(92, 19);
            LblPassword.TabIndex = 11;
            LblPassword.Text = "Contraseña:";
            // 
            // LblUsuario
            // 
            LblUsuario.AutoSize = true;
            LblUsuario.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            LblUsuario.ForeColor = Color.Navy;
            LblUsuario.Location = new Point(50, 101);
            LblUsuario.Name = "LblUsuario";
            LblUsuario.Size = new Size(66, 19);
            LblUsuario.TabIndex = 10;
            LblUsuario.Text = "Usuario:";
            // 
            // BtnIngresar
            // 
            BtnIngresar.BackColor = Color.Navy;
            BtnIngresar.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnIngresar.ForeColor = Color.White;
            BtnIngresar.Location = new Point(50, 185);
            BtnIngresar.Name = "BtnIngresar";
            BtnIngresar.Size = new Size(103, 36);
            BtnIngresar.TabIndex = 3;
            BtnIngresar.Text = "Ingresar";
            BtnIngresar.UseVisualStyleBackColor = false;
            BtnIngresar.Click += BtnIngresar_Click;
            // 
            // BtnSalir
            // 
            BtnSalir.BackColor = Color.Navy;
            BtnSalir.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnSalir.ForeColor = Color.White;
            BtnSalir.Location = new Point(219, 185);
            BtnSalir.Name = "BtnSalir";
            BtnSalir.Size = new Size(103, 36);
            BtnSalir.TabIndex = 4;
            BtnSalir.Text = "Salir";
            BtnSalir.UseVisualStyleBackColor = false;
            BtnSalir.Click += BtnSalir_Click;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(377, 255);
            Controls.Add(LblTitulo);
            Controls.Add(TxtPassword);
            Controls.Add(TxtUsuario);
            Controls.Add(LblPassword);
            Controls.Add(LblUsuario);
            Controls.Add(BtnIngresar);
            Controls.Add(BtnSalir);
            Margin = new Padding(2);
            Name = "Login";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Empresa de Gaseosas - Login";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label LblTitulo;
        private TextBox TxtPassword;
        private TextBox TxtUsuario;
        private Label LblPassword;
        private Label LblUsuario;
        private Button BtnIngresar;
        private Button BtnSalir;
    }
}