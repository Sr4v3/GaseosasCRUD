﻿namespace empresaGaseosas.UI
{
    partial class EmployeeManagment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            LblTitulo = new Label();
            BtnSalir = new Button();
            BtnCreateEmployee = new Button();
            BtnConsultar = new Button();
            BtnDelete = new Button();
            BtnUpdate = new Button();
            TxtEmployeeName = new TextBox();
            CBDocumentType = new ComboBox();
            label2 = new Label();
            label1 = new Label();
            IntEmployeeId = new TextBox();
            label4 = new Label();
            TxtDocNumber = new TextBox();
            LblUsuario = new Label();
            BtnIngresar = new Button();
            label5 = new Label();
            TxtEmployeeLName = new TextBox();
            label6 = new Label();
            TxtEmployeeMail = new TextBox();
            label7 = new Label();
            label3 = new Label();
            TxtEmployeePhone = new TextBox();
            TxtPassword2 = new TextBox();
            label8 = new Label();
            TxtPassword = new TextBox();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            CBWorkArea = new ComboBox();
            CBEducationLevel = new ComboBox();
            CBEmployeeState = new ComboBox();
            label13 = new Label();
            TxtEmployeeHiring = new TextBox();
            SuspendLayout();
            // 
            // LblTitulo
            // 
            LblTitulo.AutoSize = true;
            LblTitulo.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            LblTitulo.ForeColor = Color.Navy;
            LblTitulo.Location = new Point(269, 9);
            LblTitulo.Margin = new Padding(4, 0, 4, 0);
            LblTitulo.Name = "LblTitulo";
            LblTitulo.Size = new Size(159, 19);
            LblTitulo.TabIndex = 38;
            LblTitulo.Text = "Gestión de empleados";
            // 
            // BtnSalir
            // 
            BtnSalir.BackColor = Color.Navy;
            BtnSalir.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnSalir.ForeColor = Color.White;
            BtnSalir.Location = new Point(858, 30);
            BtnSalir.Name = "BtnSalir";
            BtnSalir.Size = new Size(103, 36);
            BtnSalir.TabIndex = 39;
            BtnSalir.Text = "Salir";
            BtnSalir.UseVisualStyleBackColor = false;
            BtnSalir.Click += BtnSalir_Click;
            // 
            // BtnCreateEmployee
            // 
            BtnCreateEmployee.BackColor = Color.Navy;
            BtnCreateEmployee.Font = new Font("Candara", 9F);
            BtnCreateEmployee.ForeColor = Color.White;
            BtnCreateEmployee.Location = new Point(818, 177);
            BtnCreateEmployee.Margin = new Padding(4, 5, 4, 5);
            BtnCreateEmployee.Name = "BtnCreateEmployee";
            BtnCreateEmployee.Size = new Size(117, 36);
            BtnCreateEmployee.TabIndex = 58;
            BtnCreateEmployee.Text = "Nuevo Empleado";
            BtnCreateEmployee.UseVisualStyleBackColor = false;
            BtnCreateEmployee.Click += BtnCreateEmployee_Click;
            // 
            // BtnConsultar
            // 
            BtnConsultar.BackColor = Color.Navy;
            BtnConsultar.Font = new Font("Candara", 9F);
            BtnConsultar.ForeColor = Color.White;
            BtnConsultar.Location = new Point(818, 131);
            BtnConsultar.Margin = new Padding(4, 5, 4, 5);
            BtnConsultar.Name = "BtnConsultar";
            BtnConsultar.Size = new Size(117, 36);
            BtnConsultar.TabIndex = 57;
            BtnConsultar.Text = "Consultar";
            BtnConsultar.UseVisualStyleBackColor = false;
            BtnConsultar.Click += BtnConsultar_Click;
            // 
            // BtnDelete
            // 
            BtnDelete.BackColor = Color.Navy;
            BtnDelete.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnDelete.ForeColor = Color.White;
            BtnDelete.Location = new Point(799, 223);
            BtnDelete.Margin = new Padding(4, 5, 4, 5);
            BtnDelete.Name = "BtnDelete";
            BtnDelete.Size = new Size(162, 58);
            BtnDelete.TabIndex = 56;
            BtnDelete.Text = "Inactivar";
            BtnDelete.UseVisualStyleBackColor = false;
            BtnDelete.Click += BtnDelete_Click;
            // 
            // BtnUpdate
            // 
            BtnUpdate.BackColor = Color.Navy;
            BtnUpdate.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnUpdate.ForeColor = Color.White;
            BtnUpdate.Location = new Point(798, 291);
            BtnUpdate.Margin = new Padding(4, 5, 4, 5);
            BtnUpdate.Name = "BtnUpdate";
            BtnUpdate.Size = new Size(162, 58);
            BtnUpdate.TabIndex = 55;
            BtnUpdate.Text = "Actualizar";
            BtnUpdate.UseVisualStyleBackColor = false;
            BtnUpdate.Click += BtnUpdate_Click;
            // 
            // TxtEmployeeName
            // 
            TxtEmployeeName.Font = new Font("Candara Light", 10F);
            TxtEmployeeName.Location = new Point(173, 180);
            TxtEmployeeName.Margin = new Padding(4, 5, 4, 5);
            TxtEmployeeName.Name = "TxtEmployeeName";
            TxtEmployeeName.Size = new Size(177, 24);
            TxtEmployeeName.TabIndex = 54;
            // 
            // CBDocumentType
            // 
            CBDocumentType.Font = new Font("Candara Light", 10F);
            CBDocumentType.FormattingEnabled = true;
            CBDocumentType.Items.AddRange(new object[] { "--Seleccionar--", "   Cédula de Ciudadanía", "   Tarjeta de Identidad", "   Cédula de Extranjería", "   Pasaporte", "   NIT", "   Registro Civil", "   Libreta Militar", "   Documento de Identidad", "   DNI", "   Otro" });
            CBDocumentType.Location = new Point(173, 110);
            CBDocumentType.Name = "CBDocumentType";
            CBDocumentType.Size = new Size(177, 23);
            CBDocumentType.TabIndex = 52;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Navy;
            label2.Location = new Point(18, 146);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(98, 19);
            label2.TabIndex = 50;
            label2.Text = "Número Doc.";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Navy;
            label1.Location = new Point(18, 110);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(71, 19);
            label1.TabIndex = 49;
            label1.Text = "Tipo Doc.";
            // 
            // IntEmployeeId
            // 
            IntEmployeeId.Font = new Font("Candara Light", 10F);
            IntEmployeeId.Location = new Point(173, 66);
            IntEmployeeId.Margin = new Padding(4, 5, 4, 5);
            IntEmployeeId.Name = "IntEmployeeId";
            IntEmployeeId.Size = new Size(76, 24);
            IntEmployeeId.TabIndex = 44;
            // 
            // label4
            // 
            label4.Location = new Point(0, 0);
            label4.Name = "label4";
            label4.Size = new Size(100, 23);
            label4.TabIndex = 59;
            // 
            // TxtDocNumber
            // 
            TxtDocNumber.Font = new Font("Candara Light", 10F);
            TxtDocNumber.Location = new Point(173, 141);
            TxtDocNumber.Margin = new Padding(4, 5, 4, 5);
            TxtDocNumber.Name = "TxtDocNumber";
            TxtDocNumber.Size = new Size(177, 24);
            TxtDocNumber.TabIndex = 45;
            // 
            // LblUsuario
            // 
            LblUsuario.AutoSize = true;
            LblUsuario.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            LblUsuario.ForeColor = Color.Navy;
            LblUsuario.Location = new Point(18, 180);
            LblUsuario.Margin = new Padding(4, 0, 4, 0);
            LblUsuario.Name = "LblUsuario";
            LblUsuario.Size = new Size(136, 19);
            LblUsuario.TabIndex = 47;
            LblUsuario.Text = "Nombre Empleado";
            // 
            // BtnIngresar
            // 
            BtnIngresar.BackColor = Color.Navy;
            BtnIngresar.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnIngresar.ForeColor = Color.White;
            BtnIngresar.Location = new Point(798, 359);
            BtnIngresar.Margin = new Padding(4, 5, 4, 5);
            BtnIngresar.Name = "BtnIngresar";
            BtnIngresar.Size = new Size(162, 58);
            BtnIngresar.TabIndex = 46;
            BtnIngresar.Text = "Insertar";
            BtnIngresar.UseVisualStyleBackColor = false;
            BtnIngresar.Click += BtnIngresar_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.Navy;
            label5.Location = new Point(18, 66);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(93, 19);
            label5.TabIndex = 60;
            label5.Text = "Id Empleado";
            // 
            // TxtEmployeeLName
            // 
            TxtEmployeeLName.Font = new Font("Candara Light", 10F);
            TxtEmployeeLName.Location = new Point(173, 221);
            TxtEmployeeLName.Margin = new Padding(4, 5, 4, 5);
            TxtEmployeeLName.Name = "TxtEmployeeLName";
            TxtEmployeeLName.Size = new Size(177, 24);
            TxtEmployeeLName.TabIndex = 62;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.Navy;
            label6.Location = new Point(18, 221);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(136, 19);
            label6.TabIndex = 61;
            label6.Text = "Apellido Empleado";
            // 
            // TxtEmployeeMail
            // 
            TxtEmployeeMail.Font = new Font("Candara Light", 10F);
            TxtEmployeeMail.Location = new Point(173, 266);
            TxtEmployeeMail.Margin = new Padding(4, 5, 4, 5);
            TxtEmployeeMail.Name = "TxtEmployeeMail";
            TxtEmployeeMail.Size = new Size(177, 24);
            TxtEmployeeMail.TabIndex = 63;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.Navy;
            label7.Location = new Point(18, 266);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(127, 19);
            label7.TabIndex = 64;
            label7.Text = "Correo Empleado";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Navy;
            label3.Location = new Point(18, 309);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(139, 19);
            label3.TabIndex = 65;
            label3.Text = "Teléfono Empleado";
            // 
            // TxtEmployeePhone
            // 
            TxtEmployeePhone.Font = new Font("Candara Light", 10F);
            TxtEmployeePhone.Location = new Point(173, 309);
            TxtEmployeePhone.Margin = new Padding(4, 5, 4, 5);
            TxtEmployeePhone.Name = "TxtEmployeePhone";
            TxtEmployeePhone.Size = new Size(177, 24);
            TxtEmployeePhone.TabIndex = 66;
            // 
            // TxtPassword2
            // 
            TxtPassword2.Font = new Font("Candara Light", 10F);
            TxtPassword2.Location = new Point(547, 243);
            TxtPassword2.Margin = new Padding(4, 5, 4, 5);
            TxtPassword2.Name = "TxtPassword2";
            TxtPassword2.PasswordChar = '☺';
            TxtPassword2.Size = new Size(225, 24);
            TxtPassword2.TabIndex = 68;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.Navy;
            label8.Location = new Point(375, 248);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(160, 19);
            label8.TabIndex = 70;
            label8.Text = "Confirmar Contraseña";
            // 
            // TxtPassword
            // 
            TxtPassword.Font = new Font("Candara Light", 10F);
            TxtPassword.Location = new Point(547, 192);
            TxtPassword.Margin = new Padding(4, 5, 4, 5);
            TxtPassword.Name = "TxtPassword";
            TxtPassword.PasswordChar = '☻';
            TxtPassword.Size = new Size(225, 24);
            TxtPassword.TabIndex = 67;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.Navy;
            label9.Location = new Point(375, 191);
            label9.Margin = new Padding(4, 0, 4, 0);
            label9.Name = "label9";
            label9.Size = new Size(88, 19);
            label9.TabIndex = 69;
            label9.Text = "Contraseña";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.Navy;
            label10.Location = new Point(18, 349);
            label10.Margin = new Padding(4, 0, 4, 0);
            label10.Name = "label10";
            label10.Size = new Size(141, 19);
            label10.TabIndex = 71;
            label10.Text = "Fecha Contratación";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label11.ForeColor = Color.Navy;
            label11.Location = new Point(375, 71);
            label11.Margin = new Padding(4, 0, 4, 0);
            label11.Name = "label11";
            label11.Size = new Size(94, 19);
            label11.TabIndex = 74;
            label11.Text = "Área Trabajo";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label12.ForeColor = Color.Navy;
            label12.Location = new Point(375, 110);
            label12.Margin = new Padding(4, 0, 4, 0);
            label12.Name = "label12";
            label12.Size = new Size(113, 19);
            label12.TabIndex = 76;
            label12.Text = "Nivel Educativo";
            // 
            // CBWorkArea
            // 
            CBWorkArea.Font = new Font("Candara Light", 10F);
            CBWorkArea.FormattingEnabled = true;
            CBWorkArea.Items.AddRange(new object[] { "--Seleccionar--", "   Ventas", "   Administración", "   Logística", "   Operaciones", "   Finanzas", "   Recursos Humanos", "   Marketing", "   Tecnología", "   Atención al Cliente", "   Producción" });
            CBWorkArea.Location = new Point(547, 67);
            CBWorkArea.Name = "CBWorkArea";
            CBWorkArea.Size = new Size(183, 23);
            CBWorkArea.TabIndex = 77;
            // 
            // CBEducationLevel
            // 
            CBEducationLevel.Font = new Font("Candara Light", 10F);
            CBEducationLevel.FormattingEnabled = true;
            CBEducationLevel.Items.AddRange(new object[] { "--Seleccionar--", "   Primaria", "   Secundaria", "   Bachillerato", "   Técnico", "   Tecnólogo", "   Pregrado", "   Maestría", "   Doctorado", "   Postdoctorado", "   Sin estudio" });
            CBEducationLevel.Location = new Point(547, 110);
            CBEducationLevel.Name = "CBEducationLevel";
            CBEducationLevel.Size = new Size(183, 23);
            CBEducationLevel.TabIndex = 78;
            // 
            // CBEmployeeState
            // 
            CBEmployeeState.Font = new Font("Candara Light", 10F);
            CBEmployeeState.FormattingEnabled = true;
            CBEmployeeState.Items.AddRange(new object[] { "--Seleccionar--", "   Activo", "   Inactivo" });
            CBEmployeeState.Location = new Point(547, 291);
            CBEmployeeState.Name = "CBEmployeeState";
            CBEmployeeState.Size = new Size(183, 23);
            CBEmployeeState.TabIndex = 80;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label13.ForeColor = Color.Navy;
            label13.Location = new Point(375, 295);
            label13.Margin = new Padding(4, 0, 4, 0);
            label13.Name = "label13";
            label13.Size = new Size(127, 19);
            label13.TabIndex = 79;
            label13.Text = "Estado Empleado";
            // 
            // TxtEmployeeHiring
            // 
            TxtEmployeeHiring.Font = new Font("Candara Light", 10F);
            TxtEmployeeHiring.Location = new Point(173, 349);
            TxtEmployeeHiring.Margin = new Padding(4, 5, 4, 5);
            TxtEmployeeHiring.Name = "TxtEmployeeHiring";
            TxtEmployeeHiring.Size = new Size(177, 24);
            TxtEmployeeHiring.TabIndex = 81;
            // 
            // EmployeeManagment
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(973, 422);
            Controls.Add(TxtEmployeeHiring);
            Controls.Add(CBEmployeeState);
            Controls.Add(label13);
            Controls.Add(CBEducationLevel);
            Controls.Add(CBWorkArea);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(TxtPassword2);
            Controls.Add(label8);
            Controls.Add(TxtPassword);
            Controls.Add(label9);
            Controls.Add(TxtEmployeePhone);
            Controls.Add(label3);
            Controls.Add(label7);
            Controls.Add(TxtEmployeeMail);
            Controls.Add(TxtEmployeeLName);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(BtnCreateEmployee);
            Controls.Add(BtnConsultar);
            Controls.Add(BtnDelete);
            Controls.Add(BtnUpdate);
            Controls.Add(TxtEmployeeName);
            Controls.Add(CBDocumentType);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(IntEmployeeId);
            Controls.Add(label4);
            Controls.Add(TxtDocNumber);
            Controls.Add(LblUsuario);
            Controls.Add(BtnIngresar);
            Controls.Add(BtnSalir);
            Controls.Add(LblTitulo);
            Margin = new Padding(2);
            Name = "EmployeeManagment";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Empresa de Gaseosas - Gestión de Empleados";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label LblTitulo;
        private Button BtnSalir;
        private Button BtnCreateEmployee;
        private Button BtnConsultar;
        private Button BtnDelete;
        private Button BtnUpdate;
        private TextBox TxtProductDescrip;
        private ComboBox CBProductState;
        private ComboBox CBDocumentType;
        private Label label2;
        private Label label1;
        private TextBox IntEmployeeId;
        private Label label4;
        private TextBox TxtDocNumber;
        private Label LblUsuario;
        private Button BtnIngresar;
        private Label label5;
        private TextBox TxtEmployeeLName;
        private Label label6;
        private TextBox TxtEmployeeMail;
        private Label label7;
        private Label label3;
        private TextBox TxtEmployeePhone;
        private TextBox TxtPassword2;
        private Label label8;
        private TextBox TxtPassword;
        private Label label9;
        private TextBox TxtEmployeeName;
        private Label label10;
        private Label label11;
        private Label label12;
        private ComboBox CBWorkArea;
        private ComboBox CBEducationLevel;
        private ComboBox CBEmployeeState;
        private Label label13;
        private TextBox TxtEmployeeHiring;
    }
}