﻿namespace empresaGaseosas.UI
{
    partial class MainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            LblTitulo = new Label();
            BtnSalir = new Button();
            PBClientes = new PictureBox();
            PBProductos = new PictureBox();
            LLClientes = new LinkLabel();
            LLProductos = new LinkLabel();
            ((System.ComponentModel.ISupportInitialize)PBClientes).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PBProductos).BeginInit();
            SuspendLayout();
            // 
            // LblTitulo
            // 
            LblTitulo.AutoSize = true;
            LblTitulo.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            LblTitulo.ForeColor = Color.Navy;
            LblTitulo.Location = new Point(160, 22);
            LblTitulo.Name = "LblTitulo";
            LblTitulo.Size = new Size(155, 38);
            LblTitulo.TabIndex = 13;
            LblTitulo.Text = "Empresa de Gaseosas\r\nMenú Principal";
            LblTitulo.TextAlign = ContentAlignment.TopCenter;
            // 
            // BtnSalir
            // 
            BtnSalir.BackColor = Color.Navy;
            BtnSalir.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnSalir.ForeColor = Color.White;
            BtnSalir.Location = new Point(408, 222);
            BtnSalir.Name = "BtnSalir";
            BtnSalir.Size = new Size(103, 36);
            BtnSalir.TabIndex = 11;
            BtnSalir.Text = "Salir";
            BtnSalir.UseVisualStyleBackColor = false;
            BtnSalir.Click += BtnSalir_Click;
            // 
            // PBClientes
            // 
            PBClientes.Location = new Point(40, 80);
            PBClientes.Margin = new Padding(2);
            PBClientes.Name = "PBClientes";
            PBClientes.Size = new Size(104, 82);
            PBClientes.SizeMode = PictureBoxSizeMode.StretchImage;
            PBClientes.TabIndex = 14;
            PBClientes.TabStop = false;
            PBClientes.Click += PBClientes_Click;
            // 
            // PBProductos
            // 
            PBProductos.Location = new Point(340, 80);
            PBProductos.Margin = new Padding(2);
            PBProductos.Name = "PBProductos";
            PBProductos.Size = new Size(104, 83);
            PBProductos.SizeMode = PictureBoxSizeMode.StretchImage;
            PBProductos.TabIndex = 15;
            PBProductos.TabStop = false;
            PBProductos.Click += PBProductos_Click;
            // 
            // LLClientes
            // 
            LLClientes.AutoSize = true;
            LLClientes.Font = new Font("Candara Light", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            LLClientes.LinkBehavior = LinkBehavior.NeverUnderline;
            LLClientes.LinkColor = Color.Black;
            LLClientes.Location = new Point(11, 185);
            LLClientes.Margin = new Padding(2, 0, 2, 0);
            LLClientes.Name = "LLClientes";
            LLClientes.Size = new Size(158, 19);
            LLClientes.TabIndex = 18;
            LLClientes.TabStop = true;
            LLClientes.Text = "Gestión de Empleados";
            // 
            // LLProductos
            // 
            LLProductos.AutoSize = true;
            LLProductos.Font = new Font("Candara Light", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            LLProductos.LinkBehavior = LinkBehavior.NeverUnderline;
            LLProductos.LinkColor = Color.Black;
            LLProductos.Location = new Point(314, 185);
            LLProductos.Margin = new Padding(2, 0, 2, 0);
            LLProductos.Name = "LLProductos";
            LLProductos.Size = new Size(154, 19);
            LLProductos.TabIndex = 19;
            LLProductos.TabStop = true;
            LLProductos.Text = "Gestión de Productos";
            LLProductos.Click += PBProductos_Click;
            // 
            // MainMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(535, 270);
            Controls.Add(LLProductos);
            Controls.Add(LLClientes);
            Controls.Add(PBProductos);
            Controls.Add(PBClientes);
            Controls.Add(LblTitulo);
            Controls.Add(BtnSalir);
            Margin = new Padding(2);
            Name = "MainMenu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Empresa de Gaseosas - Menú Principal";
            ((System.ComponentModel.ISupportInitialize)PBClientes).EndInit();
            ((System.ComponentModel.ISupportInitialize)PBProductos).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label LblTitulo;
        private Button BtnSalir;
        private PictureBox PBClientes;
        private PictureBox PBProductos;
        private LinkLabel LLClientes;
        private LinkLabel LLProductos;
    }
}