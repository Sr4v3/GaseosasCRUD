﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace empresaGaseosas.Core.Gaseosas_BROKER
{
    internal class BrokerLogin
    {
        MySqlConnection Connection;
        BrokerConnection InsConnection = new BrokerConnection();



        internal List<string> ValidarLogin(string usuario)
        {

            Connection = InsConnection.OpenConnection();
            MySqlCommand transacLogeo = new MySqlCommand();
            transacLogeo.CommandText = string.Format("Select UsuarioLogin ('{0}')", usuario);
            transacLogeo.Connection = Connection;
            List<string> ReturnLogin = new List<string>();
            MySqlDataReader ResultLogin = transacLogeo.ExecuteReader();
            while (ResultLogin.Read())
            {
                ReturnLogin.Add(ResultLogin[0].ToString());
            }
            InsConnection.CloseConnection(Connection);
            return ReturnLogin;


        }
    }
}
