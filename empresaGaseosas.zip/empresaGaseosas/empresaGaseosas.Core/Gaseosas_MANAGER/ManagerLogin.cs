﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace empresaGaseosas.Core.Gaseosas_MANAGER
{
    class ManagerLogin
    {
        internal Dictionary<bool, string> ValidarLogin(string Usuario, string Password)
        {
            Gaseosas_BROKER.BrokerLogin LoginValidate = new Gaseosas_BROKER.BrokerLogin();
            Dictionary<bool, string> values = new Dictionary<bool, string>();
            List<string> Result = new List<string>();
            Result = LoginValidate.ValidarLogin(Usuario);

            if (Result.Count > 0 && !string.IsNullOrEmpty(Result[0]))
            {
                if (Result[0].ToString() == Password)
                    values.Add(true, "LogeoCorrecto");
                else
                    values.Add(false, "Contraseña incorrecta, favor valide la contraseña ingresada");
            }
            else
                values.Add(false, "El usuario no existe, por favor valide el usuario ingresado");

            return values;

        }

    }
}
